unit UCrystalFilterLogic;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Math;

type
  TFilterType = (ftChebyshev001, ftChebyshev01, ftChebyshev05, ftButterworth, 
                 ftMaxFlatness, ftLinearPhase, ftGaussian, ftGaussian6db, 
                 ftGaussian12db, ftLegrande);

  TFilterParams = record
    CenterFrequency: Real; // Hz
    Bandwidth: Real;       // Hz
    MotionalCap: Real;     // Farads
    CrystalQ: Real;
    Harmonic: Integer;
    Order: Integer;        // 2, 3, 4, 6, 8
    FilterType: TFilterType;
  end;

  TCrystalResult = record
    Frequency: Real;      // Hz
    Resistance: Real;     // Ohm
  end;

  TFilterResults = record
    Crystals: array of TCrystalResult;
    FilterImpedance: Real;
    CapBetweenCrystals: Real;
    CrystalResistance: Real;
  end;

  TMatchingResult = record
    L: Real;
    C: Real;
    L_L: Real;
    C_L: Real;
    StepUpNs: Real;
    StepUpLs: Real;
    StepDownNp: Real;
    StepDownLs: Real;
    Lin_uH: Real;
    Lout_uH: Real;
  end;

  TCrystalFilterCalc = class
  public
    class function CalculateFilter(const Params: TFilterParams): TFilterResults;
    class function CalculateMatching(f, Cp_pF, Source_Z, Load_Z: Real; Pri_Turns, Sec_Turns: Integer): TMatchingResult;
    
    // Core pole calculation methods
    class function Caluclate_2_pole_Filter(fc, q1, q2, K12, Q, Bw, Cmotional: Real): TFilterResults;
    class function Caluclate_3_pole_Filter(fc, q1, q2, K12, K23, Q, Bw, Cmotional: Real): TFilterResults;
    class function Caluclate_4_pole_Filter(fc, q1, q4, K12, K23, K34, Q, Bw, Cmotional: Real): TFilterResults;
    class function Caluclate_6_pole_Filter(fc, q1, q4, K12, K23, K34, K45, K56, Q, Bw, Cmotional: Real): TFilterResults;
    class function Caluclate_8_pole_Filter(fc, q1, q8, K12, K23, K34, K45, K56, K67, K78, Q, Bw, Cmotional: Real): TFilterResults;
  end;

implementation

{ TCrystalFilterCalc }

class function TCrystalFilterCalc.CalculateFilter(const Params: TFilterParams): TFilterResults;
begin
  Result := Default(TFilterResults);
  case Params.FilterType of
    ftChebyshev001:
      case Params.Order of
        2: Result := Caluclate_2_pole_Filter(Params.CenterFrequency, 1.4829, 1.4829, 0.7075, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 1.1811, 1.1811, 0.6818, 0.6818, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 1.0457, 1.0457, 0.7369, 0.5413, 0.7369, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 0.9372, 0.9372, 0.8088, 0.55, 0.5177, 0.55, 0.8088, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 0.8966, 0.8966, 0.843, 0.5673, 0.5198, 0.5098, 0.5198, 0.5673, 0.843, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftChebyshev01:
      case Params.Order of
        2: Result := Caluclate_2_pole_Filter(Params.CenterFrequency, 1.6382, 1.6382, 0.7106, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 1.4328, 1.4328, 0.6818, 0.6818, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 1.3451, 1.3451, 0.6850, 0.5421, 0.6850, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 1.2767, 1.2767, 0.7145, 0.5385, 0.5180, 0.5385, 0.7145, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 1.2515, 1.2515, 0.7276, 0.5451, 0.5160, 0.5100, 0.5160, 0.5451, 0.7276, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftChebyshev05:
      case Params.Order of
        2: Result := Caluclate_2_pole_Filter(Params.CenterFrequency, 1.9497, 1.9497, 0.7225, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 1.8636, 1.8636, 0.6474, 0.6474, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 1.8258, 1.8258, 0.6482, 0.5446, 0.6482, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 1.7962, 1.7962, 0.6547, 0.5326, 0.5191, 0.5326, 0.6547, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 1.7852, 1.7852, 0.6580, 0.5333, 0.5145, 0.5106, 0.5145, 0.5333, 0.6580, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftButterworth:
      case Params.Order of
        2: Result := Caluclate_2_pole_Filter(Params.CenterFrequency, 1.4142, 1.4142, 0.7071, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 1, 1, 0.7071, 0.7071, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 0.7654, 0.7654, 0.8409, 0.5412, 0.8409, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 0.5176, 0.5176, 1.1688, 0.6050, 0.5176, 0.6050, 1.1688, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 0.3902, 0.3902, 1.5187, 0.7357, 0.5537, 0.5098, 0.5537, 0.7357, 1.5187, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftMaxFlatness:
      case Params.Order of
        2: Result := Caluclate_2_pole_Filter(Params.CenterFrequency, 0.5755, 2.1479, 0.8995, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 0.3374, 2.2034, 1.7475, 0.6868, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 0.2334, 2.2404, 2.5239, 1.1725, 0.6424, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 0.4145, 1.8647, 1.9999, 0.8105, 0.6006, 1.2525, 3.0377, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 0.6591, 0.2371, 2.2644, 1.2996, 0.6187, 0.8859, 1.1297, 1.4686, 2.7026, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftLinearPhase:
      case Params.Order of
        2: Result := Caluclate_2_pole_Filter(Params.CenterFrequency, 0.6480, 2.1085, 0.8555, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 0.4328, 2.2542, 1.4886, 0.6523, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 0.4934, 0.7182, 1.6320, 0.7181, 0.7391, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 0.5898, 0.3376, 1.9556, 1.0009, 0.5777, 0.9428, 1.8719, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 0.4420, 0.1104, 2.1899, 0.9390, 0.5850, 1.0006, 1.4723, 2.3156, 5.2219, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftGaussian:
      case Params.Order of
        2: Result := Caluclate_2_pole_Filter(Params.CenterFrequency, 0.4738, 2.1850, 0.9828, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 0.5534, 2.4250, 1.3299, 0.6353, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 0.2747, 0.4083, 2.2792, 0.7553, 0.9896, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 0.2908, 0.1481, 2.5283, 0.8608, 0.6600, 1.5303, 3.8038, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 0.2926, 0.0876, 2.8076, 0.9715, 0.6274, 1.1913, 1.8036, 2.8842, 6.5640, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftGaussian6db:
      case Params.Order of
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 0.4042, 2.3380, 1.6622, 0.6911, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 0.5700, 0.9137, 1.6232, 0.7984, 0.9816, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 1.0982, 0.6446, 1.2072, 0.9523, 0.5502, 0.6743, 1.1490, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 1.3602, 0.5967, 0.9906, 1.0245, 0.6263, 0.6068, 0.7151, 0.7993, 1.2740, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftGaussian12db:
      case Params.Order of
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 0.4152, 2.3452, 1.6314, 0.6864, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 0.4188, 0.7657, 1.9888, 0.8329, 0.7396, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 0.7280, 0.4426, 1.9169, 1.1881, 0.6051, 0.8844, 1.5958, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 1.1363, 0.3993, 1.5295, 1.3873, 0.6744, 0.7699, 0.9408, 1.1096, 1.8132, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
    ftLegrande:
      case Params.Order of
        3: Result := Caluclate_3_pole_Filter(Params.CenterFrequency, 1.1737, 2.1801, 0.7933, 0.5821, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        4: Result := Caluclate_4_pole_Filter(Params.CenterFrequency, 1.0828, 1.5642, 0.7908, 0.5880, 0.5713, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        6: Result := Caluclate_6_pole_Filter(Params.CenterFrequency, 1.2732, 1.0631, 0.7271, 0.6070, 0.4925, 0.5097, 0.7426, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
        8: Result := Caluclate_8_pole_Filter(Params.CenterFrequency, 1.3603, 0.8879, 0.6912, 0.6034, 0.5128, 0.4966, 0.5031, 0.5512, 0.8428, Params.CrystalQ, Params.Bandwidth, Params.MotionalCap);
      end;
  end;
end;

class function TCrystalFilterCalc.CalculateMatching(f, Cp_pF, Source_Z, Load_Z: Real; Pri_Turns, Sec_Turns: Integer): TMatchingResult;
var
  Q, Xs, Xp, n, Lini, Louts: Real;
begin
  Result := Default(TMatchingResult);
  if (Load_Z <= Source_Z) or (f <= 0) then Exit;

  Q := Sqrt((Load_Z / Source_Z) - 1);
  Xs := Source_Z * Q;
  Xp := Load_Z / Q;
  
  Result.C := 1 / (2 * PI * f * Xs);
  Result.L := 1 / (4 * Power(PI, 2) * Power(f, 2) * (Result.C - (Cp_pF * Power(10, -12))));
  Result.L_L := Q * Source_Z / (2 * PI * f);
  Result.C_L := Q / (2 * PI * f * Load_Z);

  // Transformer matching
  if (Source_Z > 0) and (Load_Z > 0) then
  begin
    n := Sqrt(Load_Z / Source_Z);
    Lini := (4 * Source_Z) / (2 * PI * f);
    Result.Lin_uH := Lini * 1e6;
    
    // Step Up: Input to Output (Zout > Zin)
    // Ns/Np = Sqrt(Zout/Zin)
    Result.StepUpNs := Round(Sqrt(Load_Z / Source_Z) * Pri_Turns);
    Result.StepUpLs := Sqrt(Load_Z) / (2 * PI * f);

    // Step Down: Output to Input (Actually usually means Zin > Zout if we use same logic)
    // But the original code used Zin, Zout swapped in calls.
    // Let's assume StepDown means Np/Ns = Sqrt(Zin/Zout) where Zin > Zout.
    // If Load_Z > Source_Z, then StepDown from Load to Source:
    Result.StepDownNp := Round(Sqrt(Load_Z / Source_Z) * Sec_Turns);
    Result.StepDownLs := Sqrt(Load_Z) / (2 * PI * f);
  end;
end;

class function TCrystalFilterCalc.Caluclate_2_pole_Filter(fc, q1, q2, K12, Q, Bw, Cmotional: Real): TFilterResults;
var
  f1, f2, fm, Qinf, wmega, fa1, fa2, L1, L2, L, Rtemp, Ctemp, Rin, R: Real;
begin
  f1 := fc - (Bw / 2);
  f2 := fc + (Bw / 2);
  fm := Sqrt(f1 * f2);
  wmega := fc / Bw;
  Qinf := Q / wmega;
  fa1 := fm - ((Bw / 2) * ((1 / q1) - (1 / Qinf) + K12));
  fa2 := fm - ((Bw / 2) * ((1 / q1) - (1 / Qinf) - K12));
  L1 := 1 / (4 * Power(PI, 2) * Power(fa1, 2) * Cmotional);
  L2 := 1 / (4 * Power(PI, 2) * Power(fa2, 2) * Cmotional);
  L := (L1 + L2) / 2;
  Rtemp := 2 * PI * Bw * L;
  Rin := 2 * Rtemp * ((1 / q1) - (1 / Qinf));
  R := Rin / 2;

  SetLength(Result.Crystals, 2);
  Result.Crystals[0].Frequency := fa1;
  Result.Crystals[0].Resistance := (2 * PI * fm * L1) / Q;
  Result.Crystals[1].Frequency := fa2;
  Result.Crystals[1].Resistance := (2 * PI * fm * L2) / Q;
  Result.FilterImpedance := R;
  Result.CrystalResistance := (Result.Crystals[0].Resistance + Result.Crystals[1].Resistance) / 2;
end;

class function TCrystalFilterCalc.Caluclate_3_pole_Filter(fc, q1, q2, K12, K23, Q, Bw, Cmotional: Real): TFilterResults;
var
  f1, f2, fm, Qinf, wmega, fa1, fa2, fa3, L1, L2, L3, L, Rtemp, Rin, R: Real;
begin
  f1 := fc - (Bw / 2);
  f2 := fc + (Bw / 2);
  fm := Sqrt(f1 * f2);
  wmega := fc / Bw;
  Qinf := Q / wmega;
  fa1 := fm - ((Bw / 2) * ((Sqrt(2) * K23) + K12));
  fa2 := fm - ((Bw / 2) * ((Sqrt(2) * K23) - K12));
  fa3 := fm - ((Bw / 2) * (Sqrt(2) * K23));
  L1 := 1 / (4 * Power(PI, 2) * Power(fa1, 2) * Cmotional);
  L2 := 1 / (4 * Power(PI, 2) * Power(fa2, 2) * Cmotional);
  L3 := 1 / (4 * Power(PI, 2) * Power(fa3, 2) * Cmotional);
  L := (L1 + L2 + L3) / 3;
  Rtemp := 2 * PI * Bw * L;
  Rin := Rtemp * (2 * Power(K23, 2) + ((1 / q1) - (1 / Qinf))) / (1 / q1 - 1 / Qinf);
  R := Rin / 2;

  SetLength(Result.Crystals, 3);
  Result.Crystals[0].Frequency := fa1;
  Result.Crystals[0].Resistance := (2 * PI * fm * L1) / Q;
  Result.Crystals[1].Frequency := fa2;
  Result.Crystals[1].Resistance := (2 * PI * fm * L2) / Q;
  Result.Crystals[2].Frequency := fa3;
  Result.Crystals[2].Resistance := (2 * PI * fm * L3) / Q;
  Result.FilterImpedance := R;
  Result.CrystalResistance := (Result.Crystals[0].Resistance + Result.Crystals[1].Resistance + Result.Crystals[2].Resistance) / 3;
end;

class function TCrystalFilterCalc.Caluclate_4_pole_Filter(fc, q1, q4, K12, K23, K34, Q, Bw, Cmotional: Real): TFilterResults;
var
  f1, f2, fm, a, Qinf, fa1, fa2, fa3, fa4, L1, L2, L3, L4, L, Rtemp, Rout: Real;
begin
  f1 := fc - (Bw / 2);
  f2 := fc + (Bw / 2);
  fm := Sqrt(f1 * f2);
  a := fc / Bw;
  Qinf := Q / a;
  fa1 := fm - (Bw / 2) * (K23 + K12);
  fa2 := fm - (Bw / 2) * (K23 - K12);
  fa3 := fm - (Bw / 2) * (K23 + K34);
  fa4 := fm - (Bw / 2) * (K23 - K34);
  L1 := 1 / (4 * Power(PI, 2) * Power(fa1, 2) * Cmotional);
  L2 := 1 / (4 * Power(PI, 2) * Power(fa2, 2) * Cmotional);
  L3 := 1 / (4 * Power(PI, 2) * Power(fa3, 2) * Cmotional);
  L4 := 1 / (4 * Power(PI, 2) * Power(fa4, 2) * Cmotional);
  L := (L1 + L2 + L3 + L4) / 4;
  Rtemp := PI * Bw * L;
  Rout := Rtemp * (Power(K23, 2) + Power((1 / q4 - 1 / Qinf), 2)) / (1 / q4 - 1 / Qinf);

  SetLength(Result.Crystals, 4);
  Result.Crystals[0].Frequency := fa1;
  Result.Crystals[1].Frequency := fa2;
  Result.Crystals[2].Frequency := fa3;
  Result.Crystals[3].Frequency := fa4;
  Result.FilterImpedance := Rout;
  Result.CrystalResistance := (2 * PI * fm * L) / Q;
end;

class function TCrystalFilterCalc.Caluclate_6_pole_Filter(fc, q1, q4, K12, K23, K34, K45, K56, Q, Bw, Cmotional: Real): TFilterResults;
var
  f1, f2, fm, a, Qinf, fa1, fa2, fa3, fa4, fa5, fa6, L1, L2, L3, L4, L5, L6, L, Rtemp, Rout: Real;
begin
  f1 := fc - (Bw / 2);
  f2 := fc + (Bw / 2);
  fm := Sqrt(f1 * f2);
  a := fc / Bw;
  Qinf := Q / a;
  fa1 := fm - (Bw / 2) * (K23 + K12);
  fa2 := fm - (Bw / 2) * (K23 - K12);
  fa3 := fm - (Bw / 2) * (K23 + K34);
  fa4 := fm - (Bw / 2) * (K23 - K34);
  fa5 := fm - (Bw / 2) * (K45 + K56);
  fa6 := fm - (Bw / 2) * (K45 - K56);
  L1 := 1 / (4 * Power(PI, 2) * Power(fa1, 2) * Cmotional);
  L2 := 1 / (4 * Power(PI, 2) * Power(fa2, 2) * Cmotional);
  L3 := 1 / (4 * Power(PI, 2) * Power(fa3, 2) * Cmotional);
  L4 := 1 / (4 * Power(PI, 2) * Power(fa4, 2) * Cmotional);
  L5 := 1 / (4 * Power(PI, 2) * Power(fa5, 2) * Cmotional);
  L6 := 1 / (4 * Power(PI, 2) * Power(fa6, 2) * Cmotional);
  L := (L1 + L2 + L3 + L4 + L5 + L6) / 6;
  Rtemp := 2 * PI * Bw * L;
  Rout := Rtemp * (Power(K23, 2) + Power((1 / q4 - 1 / Qinf), 2)) / (1 / q4 - 1 / Qinf);

  SetLength(Result.Crystals, 6);
  Result.Crystals[0].Frequency := fa1;
  Result.Crystals[1].Frequency := fa2;
  Result.Crystals[2].Frequency := fa3;
  Result.Crystals[3].Frequency := fa4;
  Result.Crystals[4].Frequency := fa5;
  Result.Crystals[5].Frequency := fa6;
  Result.FilterImpedance := Rout;
  Result.CrystalResistance := (2 * PI * fm * L) / Q;
end;

class function TCrystalFilterCalc.Caluclate_8_pole_Filter(fc, q1, q8, K12, K23, K34, K45, K56, K67, K78, Q, Bw, Cmotional: Real): TFilterResults;
var
  f1, f2, fm, a, Qinf, fa1, fa2, fa3, fa4, fa5, fa6, fa7, fa8, L1, L2, L3, L4, L5, L6, L7, L8, L, Rtemp, Rout: Real;
begin
  f1 := fc - (Bw / 2);
  f2 := fc + (Bw / 2);
  fm := Sqrt(f1 * f2);
  a := fc / Bw;
  Qinf := Q / a;
  fa1 := fm - (Bw / 2) * (K23 + K12);
  fa2 := fm - (Bw / 2) * (K23 - K12);
  fa3 := fm - (Bw / 2) * (K23 + K34);
  fa4 := fm - (Bw / 2) * (K23 - K34);
  fa5 := fm - (Bw / 2) * (K45 + K56);
  fa6 := fm - (Bw / 2) * (K45 - K56);
  fa7 := fm - (Bw / 2) * (K45 + K67);
  fa8 := fm - (Bw / 2) * (K45 - K67);
  L1 := 1 / (4 * Power(PI, 2) * Power(fa1, 2) * Cmotional);
  L2 := 1 / (4 * Power(PI, 2) * Power(fa2, 2) * Cmotional);
  L3 := 1 / (4 * Power(PI, 2) * Power(fa3, 2) * Cmotional);
  L4 := 1 / (4 * Power(PI, 2) * Power(fa4, 2) * Cmotional);
  L5 := 1 / (4 * Power(PI, 2) * Power(fa5, 2) * Cmotional);
  L6 := 1 / (4 * Power(PI, 2) * Power(fa6, 2) * Cmotional);
  L7 := 1 / (4 * Power(PI, 2) * Power(fa7, 2) * Cmotional);
  L8 := 1 / (4 * Power(PI, 2) * Power(fa8, 2) * Cmotional);
  L := (L1 + L2 + L3 + L4 + L5 + L6 + L7 + L8) / 8;
  Rtemp := 2 * PI * Bw * L;
  Rout := Rtemp * (Power(K78, 2) + Power((1 / q8 - 1 / Qinf), 2)) / (1 / q8 - 1 / Qinf);

  SetLength(Result.Crystals, 8);
  Result.Crystals[0].Frequency := fa1;
  Result.Crystals[1].Frequency := fa2;
  Result.Crystals[2].Frequency := fa3;
  Result.Crystals[3].Frequency := fa4;
  Result.Crystals[4].Frequency := fa5;
  Result.Crystals[5].Frequency := fa6;
  Result.Crystals[6].Frequency := fa7;
  Result.Crystals[7].Frequency := fa8;
  Result.FilterImpedance := Rout;
  Result.CrystalResistance := (2 * PI * fm * L) / Q;
end;

end.
