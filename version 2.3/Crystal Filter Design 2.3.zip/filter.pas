unit Filter;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, ComCtrls,
  StdCtrls, Menus, PrintersDlgs,IniFiles,Math,Unit1,Unit2,Printers,frmAbout,
  matching,Filter_8pole,Misc_Functions,Filter_6poles,Order,osprinters,Convert,
  filter_3poles, UCrystalFilterLogic;

type

  { TForm1 }

  TForm1 = class(TForm)
    btnCalculate: TButton;
    btnExit: TButton;
    btnTest: TButton;
    cboHarmonic: TComboBox;
    cboOrder: TComboBox;
    cboUnits: TComboBox;
    cboBWUnits: TComboBox;
    cboType: TComboBox;
    Label1: TLabel;
    lblOrder: TStaticText;
    MainMenu1: TMainMenu;
    Help: TMenuItem;
    Memo1: TMemo;
    MenuItem1: TMenuItem;
    MenuItem2: TMenuItem;
    MenuItem3: TMenuItem;
    MenuItem4: TMenuItem;
    mmuOrder: TMenuItem;
    mnmMatching: TMenuItem;
    mnmHelp: TMenuItem;
    mnmFile: TMenuItem;
    mnmOpen: TMenuItem;
    mnmSave: TMenuItem;
    mnmPrint: TMenuItem;
    mnmExit: TMenuItem;
    OpenDialog: TOpenDialog;
    PrinterSetupDialog1: TPrinterSetupDialog;
    PrnDialog: TPrintDialog;
    PrinterDialog: TPrinterSetupDialog;
    SaveDialog1: TSaveDialog;
    lblBW: TStaticText;
    lblFilterType: TStaticText;
    lblCP: TStaticText;
    txtBW2: TStaticText;
    lblCrystalHarmonic: TStaticText;
    lblQ: TStaticText;
    txtCF: TEdit;
    Image1: TImage;
    lblCF: TStaticText;
    txtBW: TEdit;
    txtCi: TEdit;
    txtQ: TEdit;
    procedure btnCalculateClick(Sender: TObject);
    procedure btnExitClick(Sender: TObject);
    procedure btnTestClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure MenuItem3Click(Sender: TObject);
    procedure MenuItem4Click(Sender: TObject);
    procedure mmuOrderClick(Sender: TObject);
    procedure mnmMatchingClick(Sender: TObject);
    procedure mnmExitClick(Sender: TObject);
    procedure mnmHelpClick(Sender: TObject);
    procedure mnmOpenClick(Sender: TObject);
    procedure mnmPrintClick(Sender: TObject);
    procedure mnmSaveClick(Sender: TObject);
    procedure txtCiKeyPress(Sender: TObject; var Key: char);
  private
  public
  end;

var
  Form1: TForm1;

implementation

var
  Center_Frequency: Real;
  BandWidth: Real;
  Cmotional: Real;
  Crystal_Q: Real;
  c0: Real;
  All_info: Boolean;

{$R *.lfm}

procedure cheby_1; forward;
procedure cheby_2; forward;
procedure cheby_3; forward;
procedure butter_1; forward;
procedure Max_Flatness; forward;
procedure Linear_phase; forward;
procedure Gaussian; forward;
procedure Gaussian_6db; forward;
procedure Gaussian_12db; forward;
procedure Legrande; forward;
procedure Check_information; forward;
procedure Caluclate_2_pole_Filter(fc, q1, q2, K12, Q, Bw, Cmotional: Real); forward;
procedure Caluclate_3_pole_Filter(fc, q1, q2, K12, K23, Q, Bw, Cmotional: Real); forward;
procedure Caluclate_4_pole_Filter(fc, q1, q4, K12, K23, K34, Q, Bw, Cmotional: Real); forward;
procedure Calculate_6_Pole_Filter(fc, q1, q4, K12, K23, K34, K45, K56, Q, Bw, Cmotional: Real); forward;
procedure Caluclate_8_pole_Filter(fc, q1, q8, K12, K23, K34, K45, K56, K67, K78, Q, Bw, Cmotional: Real); forward;
procedure not_implement; forward;

procedure WriteManufactureData(const Lines: TStrings);
begin
  try
    Lines.SaveToFile('Manufacture_Data.txt');
  except
    on E: Exception do
      ShowMessage('File Manufacture_Data.txt could not be written: ' + E.Message);
  end;
end;

procedure AppendToManufactureData(const Text: string);
var
  SL: TStringList;
begin
  SL := TStringList.Create;
  try
    if FileExists('Manufacture_Data.txt') then
      SL.LoadFromFile('Manufacture_Data.txt');
    SL.Add(Text);
    SL.SaveToFile('Manufacture_Data.txt');
  finally
    SL.Free;
  end;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  cbounits.ItemIndex := 2;
  cbobwunits.ItemIndex := 0;
  cboharmonic.ItemIndex := 0;
  cbotype.itemIndex := 0;
  cboOrder.itemIndex := 0;
  txtCF.Text := '';
  memo1.Clear;
end;

procedure TForm1.MenuItem3Click(Sender: TObject);
begin
  frmConvert.indexing := 1;
  frmConvert.ShowModal;
end;

procedure TForm1.MenuItem4Click(Sender: TObject);
begin
  frmConvert.indexing := 2;
  frmConvert.ShowModal;
end;

procedure TForm1.mmuOrderClick(Sender: TObject);
begin
  Order.frmOrder.ShowModal;
end;

procedure TForm1.mnmMatchingClick(Sender: TObject);
begin
  frmMatching.ShowModal;
end;

procedure TForm1.mnmExitClick(Sender: TObject);
begin
  Application.Terminate;
end;

procedure TForm1.mnmHelpClick(Sender: TObject);
begin
  frmAbout.frmabouts.Show;
end;

procedure TForm1.mnmOpenClick(Sender: TObject);
var
  INI: TINIFile;
begin
  if OpenDialog.Execute then
  begin
    INI := TINIFile.Create(OpenDialog.FileName);
    try
      cboUnits.ItemIndex := INI.ReadInteger('Centrer Frequency', 'Units', 2);
      txtCF.text := INI.ReadString('Centrer Frequency', 'Freq', '');
      cbobwUnits.ItemIndex := INI.ReadInteger('BandWidth', 'Units', 0);
      txtBW.text := INI.ReadString('BandWidth', 'Freq', '');
      txtCi.text := INI.ReadString('Motional', 'Cap', '');
      txtQ.text := INI.ReadString('Crystal', 'Q', '');
      cboHarmonic.ItemIndex := INI.ReadInteger('Harmonic', 'Units', 0);
      cboOrder.ItemIndex := INI.ReadInteger('Type', 'Filter Order', 0);
      cboType.ItemIndex := INI.ReadInteger('Type', 'Filter Type', 0);
    finally
      INI.Free;
    end;
  end;
end;

procedure TForm1.mnmPrintClick(Sender: TObject);
var
  helper, data, params, responseData, csvFile: String;
  textarea: TRect;
  MyPrinter: TPrinter;
  mytextstyle: TTextStyle;
  bmp: TBitmap;
  f: Text;
  YPos: Integer;
  pt :Tpoint;
  procedure PrintText(const AText: string);
  var
    Lines: TStringList;
    i: Integer;
    LineHeight: Integer;
  begin
    Lines := TStringList.Create;
    try
      Lines.Text := AText;
      LineHeight := MyPrinter.Canvas.TextHeight('Wg');
      for i := 0 to Lines.Count - 1 do
      begin
        if YPos + LineHeight > MyPrinter.PaperSize.Height - 100 then
        begin
          MyPrinter.NewPage;
          YPos := 100;
        end;
        MyPrinter.Canvas.TextOut(100, YPos, Lines[i]);
        Inc(YPos, LineHeight);
      end;
    finally
      Lines.Free;
    end;
  end;

begin
  if not FileExists('Manufacture_Data.txt') then
  begin
    ShowMessage('First make the design and after print');
    Exit;
  end;

  // Collect Filter Parameters
  params := 'FILTER PARAMETERS' + LineEnding;
  params := params + 'Center Frequency: ' + txtCF.Text + ' ' + cboUnits.Text + LineEnding;
  params := params + 'Bandwidth: ' + txtBW.Text + ' ' + cboBWUnits.Text + LineEnding;
  params := params + 'Motional Cap: ' + txtCi.Text + ' fF' + LineEnding;
  params := params + 'Crystal Q: ' + txtQ.Text + LineEnding;
  params := params + 'Crystal Harmonic: ' + cboHarmonic.Text + LineEnding;
  params := params + 'Filter Order: ' + cboOrder.Text + LineEnding;
  params := params + 'Filter Type: ' + cboType.Text + LineEnding + LineEnding;

  // Collect Manufacture Data
  data := 'MANUFACTURE DATA' + LineEnding;
  AssignFile(f, 'Manufacture_Data.txt');
  Reset(f);
  try
    while not Eof(f) do
    begin
      ReadLn(f, helper);
      data := data + helper + LineEnding;
    end;
  finally
    CloseFile(f);
  end;
  data := data + LineEnding;

  // Collect Response Data
  responseData := '';
  csvFile := '';
  case cboOrder.ItemIndex of
    0: csvFile := '2_Pole_Response.csv';
    1: csvFile := '3_Pole_Response.csv';
    2: csvFile := '4_Pole_Response.csv';
    3: csvFile := '6_Pole_Response.csv';
    4: csvFile := '8_Pole_Response.csv';
  end;

  if (csvFile <> '') and FileExists(csvFile) then
  begin
    responseData := 'FILTER RESPONSE DATA' + LineEnding;
    AssignFile(f, csvFile);
    Reset(f);
    try
      while not Eof(f) do
      begin
        ReadLn(f, helper);
        responseData := responseData + helper + LineEnding;
      end;
    finally
      CloseFile(f);
    end;
  end;

  MyPrinter := Printer;
  if PrnDialog.Execute then
  begin
    MyPrinter.BeginDoc;
    try
      MyPrinter.Canvas.Font.Name := 'Courier New';
      MyPrinter.Canvas.Font.Size := 10;
      MyPrinter.Canvas.Font.Color := clBlack;
      YPos := 100;

      // 1. Filter Parameters
      PrintText(params);
      
      // 2. Printed Circuit (from frmMatching)
      if Assigned(frmMatching) then
      begin
        bmp := TBitmap.Create;
        try
           case cboOrder.ItemIndex of
           0:bmp.Assign(Form2.Image1.Picture.Bitmap); //2 pole
           1: bmp.Assign(filter_3poles.Fiter_3pole.img3pole.Picture.Bitmap); //3 pole
           2: bmp.Assign(Unit2.Form3.image1.Picture.Bitmap);//4 pole
           3:  bmp.Assign(frm6Pole.Image1.Picture.Bitmap);//6 pole
           4:  bmp.Assign(frm8pole.Image1.Picture.Bitmap);//8 pole
           end;

          
          if YPos + 400 > MyPrinter.PaperSize.Height - 100 then
          begin
            MyPrinter.NewPage;
            YPos := 100;
          end;
           pt := Printer.Canvas.PenPos;
          // Draw scaled bitmap
          MyPrinter.Canvas.StretchDraw(Rect(pt.x+0,pt.y+100,bmp.Width+1500,bmp.Height+1500),bmp);
          Inc(YPos, 1600);
        finally
          bmp.Free;
        end;
      end;

      // 3. Manufacture Data
      PrintText(data);

      // 4. Response Data
      if responseData <> '' then
        PrintText(responseData);

    finally
      MyPrinter.EndDoc;
    end;
  end;
end;

procedure TForm1.mnmSaveClick(Sender: TObject);
var
  INI: TINIFile;
begin
  if SaveDialog1.Execute then
  begin
    INI := TINIFile.Create(SaveDialog1.FileName);
    try
      INI.WriteInteger('Centrer Frequency', 'Units', cboUnits.ItemIndex);
      INI.WriteString('Centrer Frequency', 'Freq', txtCF.text);
      INI.WriteInteger('BandWidth', 'Units', cbobwUnits.ItemIndex);
      INI.WriteString('BandWidth', 'Freq', txtBW.text);
      INI.WriteString('Motional', 'Cap', txtCi.text);
      INI.WriteString('Crystal', 'Q', txtQ.text);
      INI.WriteInteger('Harmonic', 'Units', cboHarmonic.ItemIndex);
      INI.WriteInteger('Type', 'Filter Order', cboOrder.ItemIndex);
      INI.WriteInteger('Type', 'Filter Type', cboType.ItemIndex);
    finally
      INI.Free;
    end;
  end;
end;

procedure TForm1.txtCiKeyPress(Sender: TObject; var Key: char);
begin
  if not (Key in ['0'..'9', '.', #8, #9]) or ((Key = '.') and (Pos('.', TEdit(Sender).Text) > 0)) then
    Key := Char(0);
end;

procedure TForm1.btnCalculateClick(Sender: TObject);
begin
  Check_information();
  if not All_Info then Exit;

  case cboType.ItemIndex of
    0: cheby_1;
    1: cheby_2;
    2: cheby_3;
    3: butter_1;
    4: Max_Flatness;
    5: Linear_phase;
    6: Gaussian;
    7: Gaussian_6db;
    8: Gaussian_12db;
    9: Legrande;
  end;
end;

procedure TForm1.btnExitClick(Sender: TObject);
begin
  Application.Terminate;
end;

procedure TForm1.btnTestClick(Sender: TObject);
begin
  Check_information();
end;

procedure cheby_1;
begin
  case Form1.cboOrder.ItemIndex of
    0: Caluclate_2_pole_Filter(Center_Frequency, 1.4829, 1.4829, 0.7075, Crystal_Q, Bandwidth, Cmotional);
    1: Caluclate_3_pole_Filter(Center_Frequency, 1.1811, 1.1811, 0.6818, 0.6818, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 1.0457, 1.0457, 0.7369, 0.5413, 0.7369, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 0.9372, 0.9372, 0.8088, 0.55, 0.5177, 0.55, 0.8088, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 0.8966, 0.8966, 0.843, 0.5673, 0.5198, 0.5098, 0.5198, 0.5673, 0.843, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure cheby_2;
begin
  case Form1.cboOrder.ItemIndex of
    0: Caluclate_2_pole_Filter(Center_Frequency, 1.6382, 1.6382, 0.7106, Crystal_Q, Bandwidth, Cmotional);
    1: Caluclate_3_pole_Filter(Center_Frequency, 1.4328, 1.4328, 0.6818, 0.6818, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 1.3451, 1.3451, 0.6850, 0.5421, 0.6850, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 1.2767, 1.2767, 0.7145, 0.5385, 0.5180, 0.5385, 0.7145, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 1.2515, 1.2515, 0.7276, 0.5451, 0.5160, 0.5100, 0.5160, 0.5451, 0.7276, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure cheby_3;
begin
  case Form1.cboOrder.ItemIndex of
    0: Caluclate_2_pole_Filter(Center_Frequency, 1.9497, 1.9497, 0.7225, Crystal_Q, Bandwidth, Cmotional);
    1: Caluclate_3_pole_Filter(Center_Frequency, 1.8636, 1.8636, 0.6474, 0.6474, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 1.8258, 1.8258, 0.6482, 0.5446, 0.6482, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 1.7962, 1.7962, 0.6547, 0.5326, 0.5191, 0.5326, 0.6547, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 1.7852, 1.7852, 0.6580, 0.5333, 0.5145, 0.5106, 0.5145, 0.5333, 0.6580, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure butter_1;
begin
  case Form1.cboOrder.ItemIndex of
    0: Caluclate_2_pole_Filter(Center_Frequency, 1.4142, 1.4142, 0.7071, Crystal_Q, Bandwidth, Cmotional);
    1: Caluclate_3_pole_Filter(Center_Frequency, 1, 1, 0.7071, 0.7071, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 0.7654, 0.7654, 0.8409, 0.5412, 0.8409, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 0.5176, 0.5176, 1.1688, 0.6050, 0.5176, 0.6050, 1.1688, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 0.3902, 0.3902, 1.5187, 0.7357, 0.5537, 0.5098, 0.5537, 0.7357, 1.5187, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure Max_Flatness;
begin
  case Form1.cboOrder.ItemIndex of
    0: Caluclate_2_pole_Filter(Center_Frequency, 0.5755, 2.1479, 0.8995, Crystal_Q, Bandwidth, Cmotional);
    1: Caluclate_3_pole_Filter(Center_Frequency, 0.3374, 2.2034, 1.7475, 0.6868, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 0.2334, 2.2404, 2.5239, 1.1725, 0.6424, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 0.4145, 1.8647, 1.9999, 0.8105, 0.6006, 1.2525, 3.0377, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 0.6591, 0.2371, 2.2644, 1.2996, 0.6187, 0.8859, 1.1297, 1.4686, 2.7026, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure Linear_phase;
begin
  case Form1.cboOrder.ItemIndex of
    0: Caluclate_2_pole_Filter(Center_Frequency, 0.6480, 2.1085, 0.8555, Crystal_Q, Bandwidth, Cmotional);
    1: Caluclate_3_pole_Filter(Center_Frequency, 0.4328, 2.2542, 1.4886, 0.6523, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 0.4934, 0.7182, 1.6320, 0.7181, 0.7391, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 0.5898, 0.3376, 1.9556, 1.0009, 0.5777, 0.9428, 1.8719, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 0.4420, 0.1104, 2.1899, 0.9390, 0.5850, 1.0006, 1.4723, 2.3156, 5.2219, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure Gaussian;
begin
  case Form1.cboOrder.ItemIndex of
    0: Caluclate_2_pole_Filter(Center_Frequency, 0.4738, 2.1850, 0.9828, Crystal_Q, Bandwidth, Cmotional);
    1: Caluclate_3_pole_Filter(Center_Frequency, 0.5534, 2.4250, 1.3299, 0.6353, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 0.2747, 0.4083, 2.2792, 0.7553, 0.9896, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 0.2908, 0.1481, 2.5283, 0.8608, 0.6600, 1.5303, 3.8038, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 0.2926, 0.0876, 2.8076, 0.9715, 0.6274, 1.1913, 1.8036, 2.8842, 6.5640, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure Gaussian_6db;
begin
  case Form1.cboOrder.ItemIndex of
    0: not_implement;
    1: Caluclate_3_pole_Filter(Center_Frequency, 0.4042, 2.3380, 1.6622, 0.6911, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 0.5700, 0.9137, 1.6232, 0.7984, 0.9816, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 1.0982, 0.6446, 1.2072, 0.9523, 0.5502, 0.6743, 1.1490, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 1.3602, 0.5967, 0.9906, 1.0245, 0.6263, 0.6068, 0.7151, 0.7993, 1.2740, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure Gaussian_12db;
begin
  case Form1.cboOrder.ItemIndex of
    0: not_implement;
    1: Caluclate_3_pole_Filter(Center_Frequency, 0.4152, 2.3452, 1.6314, 0.6864, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 0.4188, 0.7657, 1.9888, 0.8329, 0.7396, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 0.7280, 0.4426, 1.9169, 1.1881, 0.6051, 0.8844, 1.5958, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 1.1363, 0.3993, 1.5295, 1.3873, 0.6744, 0.7699, 0.9408, 1.1096, 1.8132, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure Legrande;
begin
  case Form1.cboOrder.ItemIndex of
    0: not_implement;
    1: Caluclate_3_pole_Filter(Center_Frequency, 1.1737, 2.1801, 0.7933, 0.5821, Crystal_Q, Bandwidth, Cmotional);
    2: Caluclate_4_pole_Filter(Center_Frequency, 1.0828, 1.5642, 0.7908, 0.5880, 0.5713, Crystal_Q, Bandwidth, Cmotional);
    3: Calculate_6_Pole_Filter(Center_Frequency, 1.2732, 1.0631, 0.7271, 0.6070, 0.4925, 0.5097, 0.7426, Crystal_Q, Bandwidth, Cmotional);
    4: Caluclate_8_pole_Filter(Center_Frequency, 1.3603, 0.8879, 0.6912, 0.6034, 0.5128, 0.4966, 0.5031, 0.5512, 0.8428, Crystal_Q, Bandwidth, Cmotional);
  end;
end;

procedure Caluclate_2_pole_Filter(fc, q1, q2, K12, Q, Bw, Cmotional: Real);
var
  Results: TFilterResults;
begin
  Results := TCrystalFilterCalc.Caluclate_2_pole_Filter(fc, q1, q2, K12, Q, Bw, Cmotional);
  Unit1.Form2.txtCrystal1.Text := FloatToStr(Round(Results.Crystals[0].Frequency));
  Unit1.Form2.txtCrystal2.Text := FloatToStr(Round(Results.Crystals[1].Frequency));
  Unit1.Form2.txtCrystal5.Text := FloatToStr(Round(Results.Crystals[1].Resistance));
  Unit1.Form2.txtCrystal6.Text := FloatToStr(Round(Results.FilterImpedance));
  AppendToManufactureData('Crystal 1 Frequency = ' + FloatToStr(Round(Results.Crystals[0].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal 2 Frequency = ' + FloatToStr(Round(Results.Crystals[1].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal Resistance = ' + FloatToStr(Round(Results.Crystals[0].Resistance)) + ' in Ohm');
  Unit1.Form2.ShowModal;
end;

procedure Caluclate_3_pole_Filter(fc, q1, q2, K12, K23, Q, Bw, Cmotional: Real);
var
  Results: TFilterResults;
begin
  Results := TCrystalFilterCalc.Caluclate_3_pole_Filter(fc, q1, q2, K12, K23, Q, Bw, Cmotional);
  filter_3poles.Fiter_3pole.txtCrystal_1_Frequency.Text := FloatToStr(Round(Results.Crystals[0].Frequency));
  filter_3poles.Fiter_3pole.txtCrystal_2_Frequency.Text := FloatToStr(Round(Results.Crystals[1].Frequency));
  filter_3poles.Fiter_3pole.txtCrystal_3_Frequency.Text := FloatToStr(Round(Results.Crystals[2].Frequency));
  filter_3poles.Fiter_3pole.txtCrystal_Resistanse.Text := FloatToStr(Round(Results.CrystalResistance));
  filter_3poles.Fiter_3pole.txtFilter_Impedance.Text := FloatToStr(Round(Results.FilterImpedance));
  AppendToManufactureData('Crystal 1 Frequency = ' + FloatToStr(Round(Results.Crystals[0].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal 2 Frequency = ' + FloatToStr(Round(Results.Crystals[1].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal 3 Frequency = ' + FloatToStr(Round(Results.Crystals[2].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal Resistance = ' + FloatToStr(Round(Results.CrystalResistance)) + ' in Ohm');
  filter_3poles.Fiter_3pole.ShowModal;
end;

procedure Caluclate_4_pole_Filter(fc, q1, q4, K12, K23, K34, Q, Bw, Cmotional: Real);
var
  Results: TFilterResults;
begin
  Results := TCrystalFilterCalc.Caluclate_4_pole_Filter(fc, q1, q4, K12, K23, K34, Q, Bw, Cmotional);
  Unit2.Form3.txtCrystal_1_Frequency.Text := FloatToStr(Round(Results.Crystals[0].Frequency));
  Unit2.Form3.txtCrystal_2_Frequency.Text := FloatToStr(Round(Results.Crystals[1].Frequency));
  Unit2.Form3.txtFilter_Impedance.Text := FloatToStr(Round(Results.FilterImpedance));
  Unit2.Form3.txtCrystal_Resistanse.Text := FloatToStr(Round(Results.CrystalResistance));
  AppendToManufactureData('Crystal 1 Frequency = ' + FloatToStr(Round(Results.Crystals[0].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal 2 Frequency = ' + FloatToStr(Round(Results.Crystals[1].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal Resistance = ' + FloatToStr(Round(Results.CrystalResistance)) + ' in Ohm');
  Unit2.Form3.ShowModal;
end;

procedure Calculate_6_Pole_Filter(fc, q1, q4, K12, K23, K34, K45, K56, Q, Bw, Cmotional: Real);
var
  Results: TFilterResults;
begin
  Results := TCrystalFilterCalc.Caluclate_6_pole_Filter(fc, q1, q4, K12, K23, K34, K45, K56, Q, Bw, Cmotional);
  Filter_6poles.frm6Pole.txtCrystal_1_Frequency.Text := FloatToStr(Round(Results.Crystals[0].Frequency));
  Filter_6poles.frm6Pole.txtCrystal_2_Frequency.Text := FloatToStr(Round(Results.Crystals[1].Frequency));
  Filter_6poles.frm6Pole.txtCrystal_3_Frequency.Text := FloatToStr(Round(Results.Crystals[2].Frequency));
  Filter_6poles.frm6Pole.txtCrystal_4_Frequency.Text := FloatToStr(Round(Results.Crystals[3].Frequency));
  Filter_6poles.frm6Pole.txtCrystal_Resistanse.Text := FloatToStr(Round(Results.CrystalResistance));
  Filter_6poles.frm6Pole.txtFilter_Impedance.Text := FloatToStr(Round(Results.FilterImpedance));
  AppendToManufactureData('Crystal 1 Frequency = ' + FloatToStr(Round(Results.Crystals[0].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal 2 Frequency = ' + FloatToStr(Round(Results.Crystals[1].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal Resistance = ' + FloatToStr(Round(Results.CrystalResistance)) + ' in Ohm');
  Filter_6poles.frm6Pole.ShowModal;
end;

procedure Caluclate_8_pole_Filter(fc, q1, q8, K12, K23, K34, K45, K56, K67, K78, Q, Bw, Cmotional: Real);
var
  Results: TFilterResults;
begin
  Results := TCrystalFilterCalc.Caluclate_8_pole_Filter(fc, q1, q8, K12, K23, K34, K45, K56, K67, K78, Q, Bw, Cmotional);
  Filter_8pole.frm8pole.txtCrystal_1_Frequency.Text := FloatToStr(Round(Results.Crystals[0].Frequency));
  Filter_8pole.frm8pole.txtCrystal_2_Frequency.Text := FloatToStr(Round(Results.Crystals[1].Frequency));
  Filter_8pole.frm8pole.txtCrystal_3_Frequency.Text := FloatToStr(Round(Results.Crystals[2].Frequency));
  Filter_8pole.frm8pole.txtCrystal_4_Frequency.Text := FloatToStr(Round(Results.Crystals[3].Frequency));
  Filter_8pole.frm8pole.txtFilter_Impedance.Text := FloatToStr(Round(Results.FilterImpedance));
  Filter_8pole.frm8pole.txtCrystal_Resistanse.Text := FloatToStr(Round(Results.CrystalResistance));
  AppendToManufactureData('Crystal 1 Frequency = ' + FloatToStr(Round(Results.Crystals[0].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal 2 Frequency = ' + FloatToStr(Round(Results.Crystals[1].Frequency)) + ' in Hz');
  AppendToManufactureData('Crystal Resistance = ' + FloatToStr(Round(Results.CrystalResistance)) + ' in Ohm');
  Filter_8pole.frm8pole.ShowModal;
end;

procedure Check_information;
var
  INI: TINIFile;
  Electrode_Diameter, Electrode_Area, Diameter, PlateBack, temp: Real;
  ButtonSelect, Harmonic: Integer;
  fs: TFormatSettings;
  SL: TStringList;
begin
  fs := DefaultFormatSettings;
  fs.DecimalSeparator := '.';
  All_info := True;
  Form1.Memo1.Clear;

  if Form1.txtcf.Text = '' then
  begin
    ShowMessage('Enter Center Frequency');
    All_info := False; Form1.txtcf.SetFocus; Exit;
  end;
  if Form1.txtBW.Text = '' then
  begin
    ShowMessage('Enter Bandwidth');
    All_info := False; Form1.txtbw.SetFocus; Exit;
  end;
  if Form1.txtCi.Text = '' then
  begin
    ShowMessage('Enter Motional Capacitance');
    All_info := False; Form1.txtCi.SetFocus; Exit;
  end;
  if Form1.txtQ.Text = '' then
  begin
    ShowMessage('Enter Crystal Q ');
    All_info := False; Form1.txtQ.SetFocus; Exit;
  end;

  if not TryStrToFloat(Form1.txtBw.Text, BandWidth, fs) then
  begin
    fs.DecimalSeparator := ',';
    if not TryStrToFloat(Form1.txtBw.Text, BandWidth, fs) then
    begin
      ShowMessage('Invalid Bandwidth format'); All_info := False; Exit;
    end;
  end;

  fs.DecimalSeparator := '.';
  if not TryStrToFloat(Form1.txtcf.Text, Center_Frequency, fs) then
  begin
    fs.DecimalSeparator := ',';
    if not TryStrToFloat(Form1.txtcf.Text, Center_Frequency, fs) then
    begin
      ShowMessage('Invalid Center Frequency format'); All_info := False; Exit;
    end;
  end;

  fs.DecimalSeparator := '.';
  if not TryStrToFloat(Form1.txtQ.Text, Crystal_Q, fs) then
  begin
    fs.DecimalSeparator := ',';
    if not TryStrToFloat(Form1.txtQ.Text, Crystal_Q, fs) then
    begin
      ShowMessage('Invalid Crystal Q format'); All_info := False; Exit;
    end;
  end;

  fs.DecimalSeparator := '.';
  if not TryStrToFloat(Form1.txtCi.Text, Cmotional, fs) then
  begin
    fs.DecimalSeparator := ',';
    if not TryStrToFloat(Form1.txtCi.Text, Cmotional, fs) then
    begin
      ShowMessage('Invalid Motional Capacitance format'); All_info := False; Exit;
    end;
  end;

  Cmotional := Cmotional * 1e-15;
  case Form1.cboHarmonic.ItemIndex of
    0: Harmonic := 1;
    1: Harmonic := 3;
    2: Harmonic := 5;
  else
    Harmonic := 1;
  end;

  case Form1.cboBwunits.ItemIndex of
    0: BandWidth := BandWidth * 1;
    1: BandWidth := BandWidth * 1000;
    2: BandWidth := BandWidth * 1000000;
  end;

  case Form1.cbounits.ItemIndex of
    0: Center_Frequency := Center_Frequency * 1;
    1: Center_Frequency := Center_Frequency * 1000;
    2: Center_Frequency := Center_Frequency * 1000000;
  end;

  if BandWidth > Center_Frequency then
  begin
    Form1.txtBw.Text := '';
    ShowMessage('Bandwidth could not be larger than center Frequency');
    All_info := False; Form1.txtBw.SetFocus; Exit;
  end;

  if BandWidth > (0.1 * Center_Frequency) then
  begin
    ButtonSelect := MessageDlg('Question', 'The Bandwidth exceed the theoretically 10%. Continue?', mtError, mbOKCancel, 0);
    if ButtonSelect = mrCancel then begin All_info := False; Exit; end;
  end;

  Crystal_Q := Crystal_Q * 1000;
  if ((Crystal_Q <= 60000) and (Form1.cboharmonic.ItemIndex >= 1)) or
     ((Crystal_Q >= 51000) and (Form1.cboharmonic.ItemIndex = 0)) then
  begin
    ShowMessage('Crystal Q range warning.');
  end;

  if (Form1.cbotype.ItemIndex >= 7) and (Form1.cboorder.ItemIndex = 0) then
  begin
    Form1.cboorder.ItemIndex := 1;
    ShowMessage('Select higher order for this filter type');
    All_info := False; Exit;
  end;

  INI := TINIFile.Create('Temp.ini');
  try
    INI.WriteInteger('Centrer Frequency', 'Units', Form1.cboUnits.ItemIndex);
    INI.WriteString('Centrer Frequency', 'Freq', Form1.txtCF.Text);
    INI.WriteInteger('BandWidth', 'Units', Form1.cbobwUnits.ItemIndex);
    INI.WriteString('BandWidth', 'Freq', Form1.txtBW.Text);
    INI.WriteString('Motional', 'Cap', Form1.txtCi.Text);
    INI.WriteString('Crystal', 'Q', Form1.txtQ.Text);
    INI.WriteInteger('Harmonic', 'Units', Form1.cboHarmonic.ItemIndex);
    INI.WriteInteger('Type', 'Filter Order', Form1.cboOrder.ItemIndex);
    INI.WriteInteger('Type', 'Filter Type', Form1.cboType.ItemIndex);
  finally
    INI.Free;
  end;

  Form1.Memo1.Lines.Add('Center Frequency ' + FloatToStr(Center_Frequency));
  Electrode_Diameter := Electrode(Center_Frequency / 1e6, Cmotional * 1e15);
  Electrode_Area := Electrode_Diameter;
  Form1.Memo1.Lines.Add('Electrode Area = ' + FloatToStr(Electrode_Area));
  Electrode_Diameter := Sqrt(Electrode_Area / 3.14) * 2;
  Diameter := Electrode_Diameter * 100;
  Form1.Memo1.Lines.Add('Electrode diameter (mm) = ' + FloatToStr(Electrode_Diameter * 1000));
  c0 := Calculate_C0(Center_Frequency, Electrode_Area, Harmonic);
  PlateBack := (Center_Frequency * 2.98) / Power(Harmonic, 2) * Power(((1660 / Center_Frequency) * 10 / Diameter), 2);
  PlateBack := Round((PlateBack / 1e3) * 100);
  Form1.Memo1.Lines.Add('Maximum Plateback = ' + FloatToStr(PlateBack) + ' KHz');

  SL := TStringList.Create;
  try
    SL.Add('Manufacture Data ');
    SL.Add('Center Frequency = ' + FloatToStr(Center_Frequency) + ' in Hz');
    SL.Add('Bandwidth (-3d) = ' + FloatToStr(BandWidth) + ' in Hz');
    SL.Add('Crytsal Harmonic = ' + Form1.cboharmonic.Text);
    SL.Add('Electrode Diameter = ' + FloatToStr(Electrode_Diameter * 39370.0787) + ' in mils');
    SL.Add('Recommended PlateBack = ' + FloatToStr(PlateBack));
    WriteManufactureData(SL);
  finally
    SL.Free;
  end;
end;

procedure not_implement;
begin
  ShowMessage('This feature has not been implemented yet');
end;

end.
