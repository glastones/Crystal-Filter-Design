unit matching;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  Buttons;

type

  { TfrmMatching }

  TfrmMatching = class(TForm)
    btnCalculateC: TBitBtn;
    btnExit: TButton;
    cboUnits: TComboBox;
    cboUnitsL: TComboBox;
    cboStepUp: TComboBox;
    cboStepDown: TComboBox;
    txtNotice: TEdit;
    Label22: TLabel;
    Label23: TLabel;
    Label24: TLabel;
    Label25: TLabel;
    Lin: TEdit;
    txtStepupSec: TEdit;
    txtStepDownPri: TEdit;
    txtPri: TEdit;
    txtSec: TEdit;
    Lout: TEdit;
    Image1: TImage;
    Image2: TImage;
    Label20: TLabel;
    Label21: TLabel;
    txtStepDown: TEdit;
    txtStepDownZS: TEdit;
    txtStepDownZL: TEdit;
    txtCFStepup: TEdit;
    txtStepupZL: TEdit;
    txtStepUpZS: TEdit;
    ImageCmatching: TImage;
    imgLmatching: TImage;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Label18: TLabel;
    Label19: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    txtCResult: TEdit;
    txtLResult: TEdit;
    txtLResultL: TEdit;
    txtCResultL: TEdit;
    txtFreq: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    txtCP: TEdit;
    txtFreqL: TEdit;
    txtLRL: TEdit;
    txtSL: TEdit;
    txtLR: TEdit;
    txtSLL: TEdit;
    procedure btnCalculateCClick({%H-}Sender: TObject);
    procedure btnExitClick({%H-}Sender: TObject);
    procedure cboStepDownChange({%H-}Sender: TObject);
    procedure cboStepUpChange({%H-}Sender: TObject);
    procedure cboUnitsChange({%H-}Sender: TObject);
    procedure cboUnitsLChange({%H-}Sender: TObject);
    procedure FormActivate({%H-}Sender: TObject);
    procedure FormClose({%H-}Sender: TObject; var {%H-}CloseAction: TCloseAction);
    procedure FormCreate({%H-}Sender: TObject);
    procedure txtCFStepupChange({%H-}Sender: TObject);
    procedure txtFreqChange({%H-}Sender: TObject);
    procedure txtFreqLChange({%H-}Sender: TObject);
    procedure txtLRChange({%H-}Sender: TObject);
    procedure txtLRLChange({%H-}Sender: TObject);
    procedure txtPriChange(Sender: TObject);
    procedure txtSecChange(Sender: TObject);
    procedure txtSLChange({%H-}Sender: TObject);
    procedure txtSLLChange({%H-}Sender: TObject);
    procedure txtStepDownChange({%H-}Sender: TObject);
    procedure txtStepDownZLChange({%H-}Sender: TObject);
    procedure txtStepDownZSChange({%H-}Sender: TObject);
    procedure txtStepupZLChange({%H-}Sender: TObject);
    procedure txtStepUpZSChange({%H-}Sender: TObject);
  private
   var calc:Boolean;
  public

  end;

var
  frmMatching: TfrmMatching;
  procedure Reset_form;
implementation
uses Filter, UCrystalFilterLogic;
{$R *.lfm}

{ TfrmMatching }
procedure Reset_form;

begin

    with frmMatching do
begin
 txtStepDownZL.Text:='';
 txtStepDownZS.Text:='';
 txtStepDown.Text:='';
 txtStepDownZS.Text:='';
 txtCP.Text:='';
 Lin.Text:='';
 Lout.Text:='';
 txtCFStepup.Text:='';
 txtStepUpZL.Text:='';
 txtStepupZS.Text:='';
 txtSL.Text:='';
 txtLR.Text:='';
 txtSLL.Text:='';
 txtLRL.Text:='';
 //txtFreqL.Text:='';
 txtCResult.Text:='';
 txtCResultL.Text:='';
 txtLResultL.Text:='';
 txtLResult.Text:='';
 txtStepDownPri.Text:='';
 txtstepupSec.Text:='';
 cbounits.ItemIndex:=0;
 cboUnitsL.ItemIndex:=0;
 cboStepUp.ItemIndex:=0;
 cboStepDown.ItemIndex:=0;
 txtPri.Text:='20';
 txtSec.Text:='20';
 calc:=False;
    //transfer center frequency from the main form
    if length(Filter.Form1.txtCF.Text)<> 0 then
frmMatching.txtFreq.Text:=Filter.Form1.txtCF.Text
else
Form1.txtcf.Text:='';

end;
   end;

procedure TfrmMatching.FormCreate(Sender: TObject);
begin
Reset_form;
 end;



procedure TfrmMatching.txtCFStepupChange(Sender: TObject);
begin
 txtFreqL.Text:=txtCFStepup.Text;
 txtStepDown.Text:=txtCFStepup.Text;
 txtFreq.Text:=txtCFStepup.Text;
end;

procedure TfrmMatching.cboUnitsChange(Sender: TObject);
begin
  cboUnitsL.ItemIndex:=cboUnits.ItemIndex;
  cboStepUp.ItemIndex :=cboUnits.ItemIndex;
  cboStepDown.ItemIndex:=cboUnits.ItemIndex;
end;

procedure TfrmMatching.btnCalculateCClick(Sender: TObject);
var
  f, Cp_pF, Source_Z, Load_Z: Real;
  Pri_Turns, Sec_Turns: Integer;
  MatchingResult: TMatchingResult;
  fs: TFormatSettings;
begin
  fs := DefaultFormatSettings;
  fs.DecimalSeparator := '.';
  
  // Basic validation and input parsing
  if not TryStrToFloat(txtFreq.Text, f, fs) then f := 0;
  if not TryStrToFloat(txtCP.Text, Cp_pF, fs) then Cp_pF := 1;
  if not TryStrToFloat(txtSL.Text, Source_Z, fs) then Source_Z := 50;
  if not TryStrToFloat(txtLR.Text, Load_Z, fs) then Load_Z := 100;
  
  Pri_Turns := StrToIntDef(txtPri.Text, 20);
  Sec_Turns := StrToIntDef(txtSec.Text, 20);

  // Frequency unit conversion to Hz
  case cboUnits.ItemIndex of
    0: f := f * 1e6; // MHz
    1: f := f * 1e3; // kHz
    2: f := f * 1;   // Hz
  end;

  if Load_Z <= Source_Z then
  begin
    ShowMessage('Error. Load Impedance must be bigger than Source Impedance for L-network');
    Exit;
  end;

  // Use the new logic unit
  MatchingResult := TCrystalFilterCalc.CalculateMatching(f, Cp_pF, Source_Z, Load_Z, Pri_Turns, Sec_Turns);

  // Display results
  txtCResult.Text := FloatToStr(Round(MatchingResult.C * 1e12));
  txtLResult.Text := FloatToStr(Round(MatchingResult.L * 1e6));
  txtLResultL.Text := FloatToStr(Round(MatchingResult.L_L * 1e6));
  txtCResultL.Text := FloatToStr(Round(MatchingResult.C_L * 1e12));

  Lin.Text := FloatToStr(Round(MatchingResult.Lin_uH));
  // Step up display
  txtStepupSec.Text := FloatToStr(Round(MatchingResult.StepUpNs));
  // Note: Possible Inductance of Secondary can be displayed if there's a field for it

  // Step down display
  txtStepDownPri.Text := FloatToStr(Round(MatchingResult.StepDownNp));

  calc := True;
end;

procedure TfrmMatching.btnExitClick(Sender: TObject);
begin
  Close;
end;

// Remove legacy procedures at the end of implementation
// Procedure Step_Down(Zout,Zin,f:Real); ...
// Procedure Step_Up(Zout,Zin,f:Real); ...


procedure TfrmMatching.cboStepDownChange(Sender: TObject);
begin
  cboStepUp.ItemIndex:=cboStepDown.ItemIndex;
  cboUnits.ItemIndex:=cboStepDown.ItemIndex;
  cboUnitsL.ItemIndex:=cboStepDown.ItemIndex;
end;

procedure TfrmMatching.cboStepUpChange(Sender: TObject);
begin
  cboStepDown.ItemIndex:=cboStepUp.ItemIndex;
  cboUnitsL.ItemIndex:=cboStepUp.ItemIndex;
  cboUnits.ItemIndex:=cboStepUp.ItemIndex;
end;

procedure TfrmMatching.cboUnitsLChange(Sender: TObject);
begin
cboUnits.ItemIndex:=cboUnitsL.ItemIndex;
cboStepDown.ItemIndex :=cboUnitsL.ItemIndex;
cboStepUp.ItemIndex:=cboUnitsL.ItemIndex;
end;

procedure TfrmMatching.FormActivate(Sender: TObject);
begin
  Reset_form;
end;

procedure TfrmMatching.FormClose(Sender: TObject; var CloseAction: TCloseAction
  );
begin
 Reset_form;

end;

procedure TfrmMatching.txtFreqChange(Sender: TObject);
begin
  txtfreqL.Text:=txtFreq.Text;
  txtCFStepup.Text:=txtFreq.Text;
  txtStepDown.Text:=txtFreq.Text;

end;

procedure TfrmMatching.txtFreqLChange(Sender: TObject);
begin
  txtFreq.Text:=txtFreqL.Text;
  txtCFStepup.Text:=txtFreqL.Text;
  txtStepDown.Text:=txtFreqL.Text;
end;

procedure TfrmMatching.txtLRChange(Sender: TObject);
begin
txtLRL.Text:=txtLR.Text;
txtStepupZL.Text:=txtLR.Text;
txtStepDownZL.Text:=txtLR.Text;
end;

procedure TfrmMatching.txtLRLChange(Sender: TObject);
begin
txtStepupZL.Text:=txtLRL.Text;
txtStepDownZL.Text:=txtLRL.Text;
txtLR.Text:=txtLRL.Text;
end;

procedure TfrmMatching.txtPriChange(Sender: TObject);
begin
  if calc then btnCalculateCClick(Sender);
end;

procedure TfrmMatching.txtSecChange(Sender: TObject);
begin
  if calc then btnCalculateCClick(Sender);
end;

procedure TfrmMatching.txtSLChange(Sender: TObject);
begin
txtSLL.Text:=txtSL.Text;
txtStepUpZS.Text:=txtSL.Text;
txtStepDownZS.Text:=txtSL.Text;
 end;

procedure TfrmMatching.txtSLLChange(Sender: TObject);
begin
  txtSL.Text:=txtSLL.Text;
txtStepUpZS.Text:=txtSLL.Text;
txtStepDownZS.Text:=txtSLL.Text;
end;

procedure TfrmMatching.txtStepDownChange(Sender: TObject);
begin
 txtFreq.Text:=txtStepDown.Text;
 txtFreqL.Text:=txtStepDown.Text;
 txtCFStepup.Text:=txtStepDown.Text;
end;

procedure TfrmMatching.txtStepDownZLChange(Sender: TObject);
begin
  txtLRL.Text:=txtStepDownZL.Text;
 txtStepupZL.Text:=txtStepDownZL.Text;
 txtLR.Text:=txtStepDownZL.Text;
 end;
procedure TfrmMatching.txtStepDownZSChange(Sender: TObject);
begin
  txtSL.Text:=txtStepDownZS.Text;
txtSLL.Text:=txtStepDownZS.Text;
txtStepUpZS.Text:=txtStepDownZS.Text;

end;

procedure TfrmMatching.txtStepupZLChange(Sender: TObject);
begin
txtLRL.Text:=txtStepupZL.Text;
txtStepDownZL.Text:=txtStepupZL.Text;
txtLR.Text:=txtStepupZL.Text;

end;

procedure TfrmMatching.txtStepUpZSChange(Sender: TObject);
begin
  txtSL.Text:=txtStepUpZS.Text;
txtSLL.Text:=txtStepUpZS.Text;
txtStepDownZS.Text:=txtStepUpZS.Text;
end;

end.

